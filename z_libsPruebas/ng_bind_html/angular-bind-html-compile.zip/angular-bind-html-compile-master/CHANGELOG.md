## 1.1.0

* Allow a specific scope to be passed in to the directive using `bind-html-scope`
* Add grunt code style tests and release notes

### 1.0.2

* BUGFIX: ensure element.html() always gets an HTML string if given the result of a $sce method, a TrustedValueHolderType.

### 1.0.1

* Add AngularJS dependency.

# 1.0.0

* Initial release.
