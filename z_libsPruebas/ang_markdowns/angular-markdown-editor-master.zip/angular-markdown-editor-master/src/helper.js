(function() {
  'use strict';

  angular.module('ui.markdown')

  .factory('$helper', ['$document', '$window',
    function($document, $window) {
      return {
        
      };
    }
  ]);

})();