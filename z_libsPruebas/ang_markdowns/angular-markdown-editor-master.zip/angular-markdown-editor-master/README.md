Angular Markdown Editor
======================

Angular Markdown Editor is a markdown editor of using [showdown](https://github.com/coreyti/showdown) project as markdown text parser used with angular

Clone 
-----

```shell
git clone https://github.com/JimLiu/angular-markdown-editor.git
```

Installation 
-------------

```shell
cd angular-markdown-editor
npm install
```

Getting started
---------------

If you have python installed in you system, you can just run `python -m SimpleHTTPServer 80` to quickly runing a lightweight web server, and point your browser to `http://localhost/demo/simple_editor.html` for testing.


